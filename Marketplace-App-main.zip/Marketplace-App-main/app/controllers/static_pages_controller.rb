class StaticPagesController < ApplicationController
  def home
    #TestJob.perform_async("hello")
  end
end
