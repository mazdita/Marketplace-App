class ApplicationMailer < ActionMailer::Base
  default from: 'nicomg100@gmail.com'
  layout 'mailer'
end
