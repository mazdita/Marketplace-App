class WorkerMailer < ApplicationMailer
    
    
end
