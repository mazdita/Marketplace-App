require "test_helper"

class ClientMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
