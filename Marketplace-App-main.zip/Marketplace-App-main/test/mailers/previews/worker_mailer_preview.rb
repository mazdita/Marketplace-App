# Preview all emails at http://localhost:3000/rails/mailers/worker_mailer
class WorkerMailerPreview < ActionMailer::Preview

end
